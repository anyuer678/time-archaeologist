labtool 1.2.0 sample package (fixture)
